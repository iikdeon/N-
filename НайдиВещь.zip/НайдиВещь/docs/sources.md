# Sources

Официальные страницы проверены 20 октября 2026 года.

- [1] Qfindo: Lost & Found — Google Play: https://play.google.com/store/apps/details?id=kz.qfindo.app
  - Описание приложения: публикация объявлений, поиск по карте и категориям, потенциальные совпадения, чат и уведомления; указаны ограничения и предупреждение о конфиденциальных данных.
- [2] TROOV — официальный сайт: https://troov.com/en
  - Публикация потерянных и найденных предметов, алгоритм сопоставления, подтверждение владения и возврат через места-партнёры.
- [3] TROOV Help Center — What is a match?: https://troov.com/en/faq/take-it-easy/what-is-a-match
  - Различие потенциального и подтверждённого совпадения; сервис не гарантирует нахождение предмета.
- [4] TROOV Help Center — What is the purpose of TROOV?: https://troov.com/en/faq/take-it-easy/what-is-the-purpose-of-troov
  - Описание процесса поиска и подтверждения принадлежности вещи.
- [5] FindMyLost — How it works for users: https://www.findmylost.es/en/how-it-works.html
  - Поиск по характеристикам, месту и дате, связь с нашедшим, уведомления.
- [6] FindMyLost — Business platform: https://www.findmylost.it/en/company/business.html
  - Решение для организаций, регистрация найденных вещей, распознавание фото и проверка запроса на возврат.
